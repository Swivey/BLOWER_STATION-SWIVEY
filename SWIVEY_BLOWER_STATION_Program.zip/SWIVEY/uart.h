
void uart() {
  uart_putc(uart0, 0xff);
  uart_putc(uart0, 0xff);
  uart_putc(uart0, 0xff);

}
